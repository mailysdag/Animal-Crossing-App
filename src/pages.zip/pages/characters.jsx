import { Link, useNavigate } from 'react-router-dom';
import { useEffect, useState } from 'react';
import '../App.css';

function Characters({ characters }) {
    const [characters, setCharacters] = useState([]);
    const [searchTerm, setSearchTerm] = useState("");
    const navigate = useNavigate();

    useEffect(() => {
        getSpecialCharacters().then(data => setCharacters(data));
    }, []);

    const filteredCharacters = characters.filter(char =>
        char.name.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
        <div className='home-container'>
            <h1 className='home-title'>Special characters</h1><input
                type="text"
                placeholder="Search Tom Nook, Isabelle..."
                className="search-bar npc-search"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
            />

            <button onClick={() => navigate(-1)} className="back-button" style={{ color: '#8F6135' }}>
                ← Back
            </button>

            <div className="villagers-grid">
                {filteredCharacters.map((char) => (
                    <div key={char.id} className="villager-card npc-card">
                        <div className="npc-image-container">
                            <img
                                src={char.image_url}
                                alt={char.name}
                                className="villager-img"
                            />
                        </div>

                        <p className="villager-name npc-name">{char.name}</p>
                    </div>
                ))}
            </div>
        </div>
    );
}

export default Characters;